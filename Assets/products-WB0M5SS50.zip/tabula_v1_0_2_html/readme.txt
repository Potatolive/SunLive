Thanks for buy my theme!

If you need help you can find us on http://bootstrapmaster.com

How to set up my Twitter Account
http://bootstrapmaster.com/twitter-api-1-1/

We starting soon with new mobile application and we want to invite you. We have $20 discount for you and your friends. Check us on http://nessfile.com